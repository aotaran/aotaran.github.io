Author: Ata Otaran
Email: ata.otaran@gmail.com

I provide these CAD files to aid you if you are interested in creating a similar sensor and actuator system for your pedal. 

You only need the two manufacturing files for the mounting unit (3D printed PLA/ABS) and actuator connector plate (laser cut acrylic). I included the design files (Autodesk Inventor) as well since you may have slightly different parts at hand. 

Please check the exploded view (PedalExploded.png) to get an initial idea about the connections. We used M4 screws for the connections.

Please open countersunk holes on the vibration actuator connector plate on the plane facing the vibration actuator so that you do not have a gap between them.

You should follow the following order in connections. Careful that "Part A to Part B" means that the screw should pass through Part A and then Part B. Screw head should be on Part A and the screw should either connect to Part B or tightened with a nut on Part B.

1- Mounting unit (3D printed) to the pedal arm 
2- Mounting unit to load cell
3- Pedal plate to the load cell
4- Actuator connector plate to mounting unit
5- Actuator connector plate to the vibration actuator

Feel free to connect if you have any questions.